Simulador de concentración de mercado (Monte Carlo) - Streamlit

Ejecución local:
1. Instalar Python 3.10 o superior.
2. En la carpeta del proyecto: pip install -r requirements.txt
3. Ejecutar: streamlit run app.py
4. Abrir http://localhost:8501

Contenido: app.py (aplicación), requirements.txt (dependencias).
Indicadores: CRk, IHH, ID, IE. Simulación: Dirichlet(1,...,1), suma de cuotas = 1.
